# Helm chart

This chart imports the OC Public Defenders Records Workspace into HPE AI Essentials 1.12.x. It deploys the backend, frontend and a persistent volume. GPU model endpoints are separate MLIS deployments.

Use the full installation guide in `../docs/`. Start with `deploy/examples/values-lab.yaml`, replace the registry and endpoint placeholders, create the model credential Secret, and run `python scripts/preflight.py --values deploy/values-lab.local.yaml --namespace YOUR_PROJECT_NAMESPACE`.

Generate the chart archive with `python scripts/package.py`. Upload `dist/ocpd-records-2.2.0.tgz` in **Tools & Frameworks → Import Frameworks**. Keep **Apply Helm Chart Config** off: this chart supplies manual VirtualService, authorization and HPE workload labels.

Only one backend replica with `Recreate` is supported. The PVC must support ownership by UID/GID 10001 through `fsGroup` or storage-side provisioning. No root init container or cluster-level RBAC is installed. The app never mounts a Kubernetes service account token.

Read `docs/AIE-1.12-COMPATIBILITY.md` for version-specific design and validation boundaries.
