{{- define "pcai-case-rag.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "pcai-case-rag.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "pcai-case-rag.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "pcai-case-rag.labels" -}}
helm.sh/chart: {{ include "pcai-case-rag.chart" . }}
app.kubernetes.io/name: {{ include "pcai-case-rag.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "pcai-case-rag.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pcai-case-rag.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "pcai-case-rag.backendFullname" -}}
{{- printf "%s-backend" (include "pcai-case-rag.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "pcai-case-rag.frontendFullname" -}}
{{- printf "%s-frontend" (include "pcai-case-rag.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "pcai-case-rag.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "pcai-case-rag.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "pcai-case-rag.secretName" -}}
{{- default (printf "%s-secrets" (include "pcai-case-rag.fullname" .)) .Values.secrets.existingSecret }}
{{- end }}

{{- define "pcai-case-rag.pvcName" -}}
{{- default (printf "%s-data" (include "pcai-case-rag.fullname" .)) .Values.backend.persistence.existingClaim }}
{{- end }}


{{/* Registry selection changes image locations only; no data or model settings. */}}
{{- define "ocpd.registryRepository" -}}
{{- $r := .root.Values.registry -}}
{{- if not $r.enabled -}}
{{- index .root.Values .component "image" "repository" -}}
{{- else if eq $r.provider "dockerhub" -}}
{{- printf "docker.io/%s/records-%s" $r.dockerhub.namespace .component -}}
{{- else if eq $r.provider "harbor" -}}
{{- if not (or (contains "." $r.harbor.host) (contains ":" $r.harbor.host) (eq "localhost" $r.harbor.host)) -}}
{{- fail "Harbor host must include a DNS domain, IP, or explicit port (or be localhost)" -}}
{{- end -}}
{{- printf "%s/%s/records-%s" $r.harbor.host $r.harbor.project .component -}}
{{- else -}}
{{- fail "registry.provider must be dockerhub or harbor" -}}
{{- end -}}
{{- end -}}

{{- define "ocpd.registryPullSecrets" -}}
{{- if .Values.registry.enabled -}}
{{- $active := index .Values.registry .Values.registry.provider -}}
{{- if $active.private -}}
{{- list (dict "name" (required "Active private registry requires pullSecretName" $active.pullSecretName)) | toYaml -}}
{{- else -}}
[]
{{- end -}}
{{- else -}}
{{- .Values.imagePullSecrets | toYaml -}}
{{- end -}}
{{- end -}}
