{{/* Required HPE AIE 1.12 imported-framework health and metering labels. */}}
{{- define "hpe-ezua.labels" -}}
hpe-ezua/app: {{ .Release.Name | quote }}
hpe-ezua/type: vendor-service
{{- end }}
